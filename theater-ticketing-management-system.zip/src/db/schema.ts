import {
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const halls = pgTable("halls", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rows: integer("rows").notNull().default(8),
  seatsPerRow: integer("seats_per_row").notNull().default(12),
  blockedSeats: jsonb("blocked_seats").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  genre: text("genre").notNull().default("Спектакль"),
  eventDate: text("event_date").notNull(),
  hallId: integer("hall_id").notNull().references(() => halls.id, { onDelete: "restrict" }),
  price: integer("price").notNull().default(1400),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("events_event_date_idx").on(table.eventDate)]);

export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => events.id, { onDelete: "restrict" }),
  cashier: text("cashier").notNull(),
  paymentMethod: text("payment_method").notNull(),
  total: integer("total").notNull(),
  ticketsCount: integer("tickets_count").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("sales_created_at_idx").on(table.createdAt)]);

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id").notNull().references(() => sales.id, { onDelete: "cascade" }),
  eventId: integer("event_id").notNull().references(() => events.id, { onDelete: "cascade" }),
  seatCode: text("seat_code").notNull(),
  price: integer("price").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [uniqueIndex("tickets_event_seat_unique").on(table.eventId, table.seatCode)]);
