"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";

type Role = "clerk" | "admin";
type Section = "sale" | "overview" | "events" | "halls";
type PaymentMethod = "cash" | "card";
type Notice = { kind: "success" | "error"; message: string };

type Hall = {
  id: number;
  name: string;
  rows: number;
  seatsPerRow: number;
  blockedSeats: string[];
  createdAt: string;
};

type TheatreEvent = {
  id: number;
  title: string;
  description: string;
  genre: string;
  eventDate: string;
  hallId: number;
  hallName: string;
  price: number;
  status: string;
};

type SoldTicket = { eventId: number; seatCode: string };

type Sale = {
  id: number;
  eventId: number;
  eventTitle: string;
  cashier: string;
  paymentMethod: string;
  total: number;
  ticketsCount: number;
  createdAt: string;
};

type TheatreData = {
  halls: Hall[];
  events: TheatreEvent[];
  tickets: SoldTicket[];
  sales: Sale[];
  summary: { revenue: number; ticketsCount: number; salesCount: number };
};

type EventForm = {
  title: string;
  genre: string;
  description: string;
  eventDate: string;
  hallId: string;
  price: string;
};

type HallForm = {
  name: string;
  rows: number;
  seatsPerRow: number;
  blockedSeats: string[];
};

type IconName =
  | "home"
  | "ticket"
  | "calendar"
  | "grid"
  | "chart"
  | "plus"
  | "refresh"
  | "search"
  | "bell"
  | "user"
  | "settings"
  | "clock"
  | "money"
  | "card"
  | "edit"
  | "close"
  | "arrow"
  | "check"
  | "download"
  | "receipt"
  | "theatre"
  | "lock"
  | "more";

const EMPTY_DATA: TheatreData = {
  halls: [],
  events: [],
  tickets: [],
  sales: [],
  summary: { revenue: 0, ticketsCount: 0, salesCount: 0 },
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const drawings: Record<IconName, ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-6h6v6" /></>,
    ticket: <><path d="M3 7V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a3 3 0 0 0 0 6v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a3 3 0 0 0 0-6Z" /><path d="M13 5v2m0 4v2m0 4v2" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18M8 14h2m4 0h2m-8 3h2" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    chart: <><path d="M4 19V5m0 14h17" /><path d="m7 15 4-4 3 2 6-7" /><path d="M17 6h3v3" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    refresh: <><path d="M20 7v5h-5M4 17v-5h5" /><path d="M5.6 9a7 7 0 0 1 11.7-2L20 12M4 12l2.7 5a7 7 0 0 0 11.7-2" /></>,
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4.5 4.5" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a8 8 0 0 1-1.5.9l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.5-.9l-1.7.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.8l-1.4-1.1 1.4-2.4 1.7.6a8 8 0 0 1 1.5-.9l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.5.9l1.7-.6 1.4 2.4-1.4 1.1a7 7 0 0 1 0 1.8Z" transform="translate(-1 -1)" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    money: <><rect x="2.5" y="5" width="19" height="14" rx="2" /><path d="M2.5 9h19M7 14h3" /><circle cx="16.5" cy="14" r="1.5" /></>,
    card: <><rect x="2.5" y="4" width="19" height="16" rx="2" /><path d="M2.5 9h19M7 15h4" /></>,
    edit: <><path d="m14 5 5 5M4 20l4.5-1 10-10a2.1 2.1 0 0 0-3-3l-10 10L4 20Z" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    arrow: <><path d="M5 12h14m-6-6 6 6-6 6" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5" /><path d="M4 20h16" /></>,
    receipt: <><path d="M5 3h14v18l-3-2-4 2-4-2-3 2z" /><path d="M8 8h8M8 12h8M8 16h4" /></>,
    theatre: <><path d="M3 4h18v13H3z" /><path d="M8 21h8m-4-4v4M7 8h3m4 0h3M8 13c1.5 1 2.5 1 4 0m2 0c1.5 1 2.5 1 4 0" /></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2" /></>,
    more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
  };

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {drawings[name]}
    </svg>
  );
}

function money(value: number) {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0,
  }).format(value);
}

function rowLabel(index: number) {
  let value = index + 1;
  let label = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    label = String.fromCharCode(65 + remainder) + label;
    value = Math.floor((value - 1) / 26);
  }
  return label;
}

function seatCode(row: number, seat: number) {
  return `${rowLabel(row)}${seat}`;
}

function formatEventDate(value: string, includeDay = true) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    ...(includeDay ? { weekday: "short", day: "numeric", month: "short" } : { day: "numeric", month: "short" }),
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "—"
    : new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(date);
}

function formatDateInput(value: string) {
  return value.length >= 16 ? value.slice(0, 16) : value;
}

function defaultEventDate() {
  const date = new Date(Date.now() + 24 * 60 * 60 * 1000);
  date.setHours(19, 0, 0, 0);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

async function apiRequest<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
    cache: "no-store",
  });
  const payload = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || "Не удалось выполнить операцию");
  return payload;
}

export default function HomePage() {
  const [data, setData] = useState<TheatreData>(EMPTY_DATA);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [role, setRole] = useState<Role>("clerk");
  const [section, setSection] = useState<Section>("sale");
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  const [cashReceived, setCashReceived] = useState("");
  const [savingSale, setSavingSale] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [modal, setModal] = useState<"event" | "hall" | null>(null);
  const [editingEventId, setEditingEventId] = useState<number | null>(null);
  const [editingHallId, setEditingHallId] = useState<number | null>(null);
  const [savingForm, setSavingForm] = useState(false);
  const [eventForm, setEventForm] = useState<EventForm>({
    title: "",
    genre: "Спектакль",
    description: "",
    eventDate: defaultEventDate(),
    hallId: "",
    price: "1400",
  });
  const [hallForm, setHallForm] = useState<HallForm>({
    name: "",
    rows: 8,
    seatsPerRow: 12,
    blockedSeats: [],
  });

  const loadData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const nextData = await apiRequest<TheatreData>("/api/data");
      setData(nextData);
      setLoadError("");
      setSelectedEventId((current) =>
        current && nextData.events.some((event) => event.id === current)
          ? current
          : nextData.events[0]?.id ?? null,
      );
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Ошибка загрузки данных");
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
    const timer = window.setInterval(() => void loadData(true), 45_000);
    return () => window.clearInterval(timer);
  }, [loadData]);

  useEffect(() => {
    const savedRole = window.localStorage.getItem("theatre-cashier-role");
    if (savedRole === "admin") {
      setRole("admin");
      setSection("overview");
    }
  }, []);

  const activeEvent = data.events.find((event) => event.id === selectedEventId) ?? data.events[0] ?? null;
  const activeHall = activeEvent ? data.halls.find((hall) => hall.id === activeEvent.hallId) ?? null : null;
  const soldForEvent = useMemo(
    () => new Set(data.tickets.filter((ticket) => ticket.eventId === activeEvent?.id).map((ticket) => ticket.seatCode)),
    [data.tickets, activeEvent?.id],
  );
  const receiptTotal = (activeEvent?.price ?? 0) * selectedSeats.length;
  const paidAmount = paymentMethod === "card"
    ? receiptTotal
    : Number(cashReceived || (receiptTotal ? String(receiptTotal) : "0"));
  const changeAmount = Math.max(paidAmount - receiptTotal, 0);
  const currentCashier = role === "admin" ? "Мария Андреева" : "Анна Соколова";
  const userInitials = role === "admin" ? "МА" : "АС";
  const activeCapacity = activeHall
    ? activeHall.rows * activeHall.seatsPerRow - activeHall.blockedSeats.length
    : 0;
  const freeSeats = activeCapacity - soldForEvent.size;

  const chartRows = useMemo(() => {
    const today = new Date();
    const rows: { label: string; amount: number; dateKey: string }[] = [];
    for (let offset = 6; offset >= 0; offset -= 1) {
      const date = new Date(today);
      date.setDate(today.getDate() - offset);
      const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
      const amount = data.sales
        .filter((sale) => {
          const saleDate = new Date(sale.createdAt);
          return `${saleDate.getFullYear()}-${saleDate.getMonth()}-${saleDate.getDate()}` === dateKey;
        })
        .reduce((sum, sale) => sum + sale.total, 0);
      rows.push({
        label: new Intl.DateTimeFormat("ru-RU", { weekday: "short" }).format(date).replace(".", ""),
        amount,
        dateKey,
      });
    }
    return rows;
  }, [data.sales]);

  const notify = useCallback((kind: Notice["kind"], message: string) => {
    setNotice({ kind, message });
    window.setTimeout(() => setNotice(null), 4500);
  }, []);

  function changeRole(nextRole: Role) {
    setRole(nextRole);
    window.localStorage.setItem("theatre-cashier-role", nextRole);
    setSection(nextRole === "admin" ? "overview" : "sale");
    setSelectedSeats([]);
    setCashReceived("");
  }

  function selectEvent(value: string) {
    setSelectedEventId(Number(value));
    setSelectedSeats([]);
    setCashReceived("");
  }

  function toggleSeat(code: string) {
    setSelectedSeats((current) => {
      if (current.includes(code)) return current.filter((seat) => seat !== code);
      if (current.length >= 24) {
        notify("error", "В одном чеке можно оформить не более 24 билетов");
        return current;
      }
      return [...current, code];
    });
    setCashReceived("");
  }

  async function completeSale() {
    if (!activeEvent || selectedSeats.length === 0) {
      notify("error", "Сначала выберите места на схеме зала");
      return;
    }
    if (paymentMethod === "cash" && paidAmount < receiptTotal) {
      notify("error", "Внесённой суммы недостаточно для оплаты");
      return;
    }

    setSavingSale(true);
    try {
      await apiRequest("/api/sales", {
        method: "POST",
        body: JSON.stringify({
          eventId: activeEvent.id,
          seatCodes: selectedSeats,
          paymentMethod,
          cashier: currentCashier,
        }),
      });
      const count = selectedSeats.length;
      setSelectedSeats([]);
      setCashReceived("");
      notify("success", `Чек пробит: ${count} ${count === 1 ? "билет" : count < 5 ? "билета" : "билетов"} · ${money(receiptTotal)}`);
      await loadData(true);
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Не удалось оформить продажу");
      await loadData(true);
    } finally {
      setSavingSale(false);
    }
  }

  function openEventForm(event?: TheatreEvent) {
    setEditingEventId(event?.id ?? null);
    setEventForm(event
      ? {
          title: event.title,
          genre: event.genre,
          description: event.description,
          eventDate: formatDateInput(event.eventDate),
          hallId: String(event.hallId),
          price: String(event.price),
        }
      : {
          title: "",
          genre: "Спектакль",
          description: "",
          eventDate: defaultEventDate(),
          hallId: data.halls[0] ? String(data.halls[0].id) : "",
          price: "1400",
        });
    setModal("event");
  }

  function openHallForm(hall?: Hall) {
    setEditingHallId(hall?.id ?? null);
    setHallForm(hall
      ? { name: hall.name, rows: hall.rows, seatsPerRow: hall.seatsPerRow, blockedSeats: [...hall.blockedSeats] }
      : { name: "Новый зал", rows: 8, seatsPerRow: 12, blockedSeats: [] });
    setModal("hall");
  }

  async function saveEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingForm(true);
    try {
      const payload = {
        ...eventForm,
        hallId: Number(eventForm.hallId),
        price: Number(eventForm.price),
      };
      await apiRequest(editingEventId ? `/api/events/${editingEventId}` : "/api/events", {
        method: editingEventId ? "PATCH" : "POST",
        body: JSON.stringify(payload),
      });
      setModal(null);
      notify("success", editingEventId ? "Изменения мероприятия сохранены" : "Мероприятие добавлено в афишу");
      await loadData(true);
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Не удалось сохранить мероприятие");
    } finally {
      setSavingForm(false);
    }
  }

  async function saveHall(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingForm(true);
    try {
      const endpoint = editingHallId ? `/api/halls/${editingHallId}` : "/api/halls";
      await apiRequest(endpoint, {
        method: editingHallId ? "PATCH" : "POST",
        body: JSON.stringify(hallForm),
      });
      setModal(null);
      notify("success", editingHallId ? "Схема зала обновлена" : "Новый зал создан");
      await loadData(true);
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Не удалось сохранить зал");
    } finally {
      setSavingForm(false);
    }
  }

  function toggleBlockedSeat(code: string) {
    setHallForm((current) => ({
      ...current,
      blockedSeats: current.blockedSeats.includes(code)
        ? current.blockedSeats.filter((seat) => seat !== code)
        : [...current.blockedSeats, code],
    }));
  }

  const protectedSeats = useMemo(() => {
    if (!editingHallId) return new Set<string>();
    const eventIds = new Set(data.events.filter((event) => event.hallId === editingHallId).map((event) => event.id));
    return new Set(data.tickets.filter((ticket) => eventIds.has(ticket.eventId)).map((ticket) => ticket.seatCode));
  }, [data.events, data.tickets, editingHallId]);

  const allSalesTotal = role === "admin"
    ? data.summary.revenue
    : data.sales.filter((sale) => sale.cashier === currentCashier).reduce((sum, sale) => sum + sale.total, 0);
  const clerkSales = role === "admin"
    ? data.sales
    : data.sales.filter((sale) => sale.cashier === currentCashier);
  const chartMax = Math.max(1, ...chartRows.map((row) => row.amount));

  const navigation: { id: Section; label: string; icon: IconName }[] = role === "admin"
    ? [
        { id: "overview", label: "Сводка", icon: "chart" },
        { id: "sale", label: "Касса", icon: "ticket" },
        { id: "events", label: "Мероприятия", icon: "calendar" },
        { id: "halls", label: "Залы", icon: "grid" },
      ]
    : [
        { id: "sale", label: "Продажа билетов", icon: "ticket" },
        { id: "overview", label: "Моя смена", icon: "chart" },
      ];

  return (
    <main className="app-frame">
      <div className="system-strip">
        <div className="system-brand"><span className="brand-mark"><Icon name="theatre" size={18} /></span><span>Театр.Касса</span><span className="system-caption">(1С:Предприятие)</span></div>
        <div className="system-tools"><span className="system-dot" /><span>Рабочая база</span><span className="system-tool-divider" /><button aria-label="Уведомления" className="chrome-icon"><Icon name="bell" size={15} /></button><span className="window-controls">−　□　×</span></div>
      </div>

      <header className="workspace-header">
        <div className="header-left">
          <div className="header-logo"><span>Т</span></div>
          <div className="header-heading"><div className="breadcrumbs">Театр / <strong>{section === "sale" ? "Кассовое место" : section === "overview" ? "Сводка" : section === "events" ? "Афиша" : "Залы"}</strong></div><div className="workspace-title">Театр.Касса <span className="title-separator">/</span> <span>{role === "admin" ? "Предприятие" : "Рабочее место кассира"}</span></div></div>
        </div>
        <div className="header-right">
          <div className="live-status"><span className="live-dot" /> База данных подключена</div>
          <div className="role-switch" aria-label="Роль пользователя">
            <button className={role === "clerk" ? "role-option active" : "role-option"} onClick={() => changeRole("clerk")}><Icon name="ticket" size={15} />Билетёр</button>
            <button className={role === "admin" ? "role-option active" : "role-option"} onClick={() => changeRole("admin")}><Icon name="settings" size={15} />Администратор</button>
          </div>
          <div className="account-chip"><span className="avatar">{userInitials}</span><div><strong>{role === "admin" ? "М. Андреева" : "А. Соколова"}</strong><small>{role === "admin" ? "Администратор" : "Билетёр"}</small></div></div>
        </div>
      </header>

      <div className="app-layout">
        <aside className="sidebar">
          <div className="sidebar-label">РАБОЧИЙ СТОЛ</div>
          <nav className="sidebar-nav" aria-label="Главная навигация">
            {navigation.map((item) => (
              <button key={item.id} className={`nav-item ${section === item.id ? "selected" : ""}`} onClick={() => setSection(item.id)}>
                <span className="nav-icon"><Icon name={item.icon} size={18} /></span><span>{item.label}</span>{section === item.id && <span className="nav-indicator" />}
              </button>
            ))}
          </nav>
          <div className="sidebar-bottom">
            <div className="sidebar-rule" />
            <button className="nav-item muted-nav" onClick={() => void loadData()}><span className="nav-icon"><Icon name="refresh" size={17} /></span><span>Обновить данные</span></button>
            <div className="shift-card"><div className="shift-card-icon"><Icon name="clock" size={16} /></div><div><small>КАССОВАЯ СМЕНА</small><strong>Открыта</strong></div><span className="live-dot" /></div>
            <div className="sidebar-footer">Театр им. А. Чехова <span>v 1.4.2</span></div>
          </div>
        </aside>

        <section className="workspace-content">
          {loadError && <div className="page-alert"><Icon name="bell" size={17} /><span>{loadError}</span><button onClick={() => void loadData()}>Повторить</button></div>}
          {section === "sale" && (
            <>
              <div className="page-heading sale-heading">
                <div><div className="eyebrow">КАССОВОЕ МЕСТО · ПРОДАЖА</div><h1>Продажа билетов</h1><p>Выберите мероприятие и свободные места в зале</p></div>
                <div className="heading-actions"><span className="shift-open"><span className="live-dot" /> Смена открыта</span><button className="classic-button" onClick={() => void loadData()}><Icon name="refresh" size={15} />Обновить</button></div>
              </div>
              {loading && data.events.length === 0 ? <div className="loading-panel"><span className="loading-spinner" />Загружаем кассу…</div> : !activeEvent || !activeHall ? (
                <div className="empty-state"><Icon name="calendar" size={28} /><h2>Нет мероприятий для продажи</h2><p>Добавьте мероприятие и зал, чтобы начать работу с кассой.</p>{role === "admin" && <button className="classic-button primary" onClick={() => openEventForm()}><Icon name="plus" size={16} />Создать мероприятие</button>}</div>
              ) : (
                <div className="sale-layout">
                  <div className="sale-main-column">
                    <section className="terminal-toolbar panel">
                      <div className="event-picker"><label htmlFor="event-select">МЕРОПРИЯТИЕ / СЕАНС</label><select id="event-select" value={activeEvent.id} onChange={(event) => selectEvent(event.target.value)}>{data.events.map((event) => <option key={event.id} value={event.id}>{event.title} · {formatEventDate(event.eventDate)}</option>)}</select></div>
                      <div className="event-quick-info"><span className="event-genre">{activeEvent.genre}</span><span><Icon name="clock" size={14} />{formatEventDate(activeEvent.eventDate)}</span><span><Icon name="grid" size={14} />{activeHall.name}</span></div>
                      <div className="terminal-actions"><button className="icon-button" title="Обновить занятость мест" onClick={() => void loadData()}><Icon name="refresh" size={16} /></button><button className="icon-button" title="Очистить чек" onClick={() => { setSelectedSeats([]); setCashReceived(""); }}><Icon name="close" size={16} /></button></div>
                    </section>

                    <section className="seat-panel panel">
                      <div className="panel-heading"><div><div className="eyebrow">СХЕМА ЗАЛА</div><h2>Выбор мест</h2></div><div className="seat-availability"><strong>{freeSeats}</strong><span>свободно из {activeCapacity}</span></div></div>
                      <div className="stage-wrap"><div className="stage-label"><span />СЦЕНА<span /></div><div className="stage-surface" /></div>
                      <div className="seat-map-scroll"><div className="seat-map" style={{ gridTemplateColumns: `30px repeat(${activeHall.seatsPerRow}, minmax(25px, 1fr))` }}>
                        <span className="map-corner">РЯД</span>{Array.from({ length: activeHall.seatsPerRow }, (_, index) => <span className="seat-number" key={`head-${index}`}>{index + 1}</span>)}
                        {Array.from({ length: activeHall.rows }, (_, rowIndex) => <div className="seat-row-fragment" key={`row-${rowIndex}`} style={{ display: "contents" }}>
                          <span className="row-label">{rowLabel(rowIndex)}</span>
                          {Array.from({ length: activeHall.seatsPerRow }, (_, seatIndex) => {
                            const code = seatCode(rowIndex, seatIndex + 1);
                            const isBlocked = activeHall.blockedSeats.includes(code);
                            const isSold = soldForEvent.has(code);
                            const isSelected = selectedSeats.includes(code);
                            return <button key={code} type="button" title={`${rowLabel(rowIndex)} ряд · ${seatIndex + 1} место${isBlocked ? " · закрыто" : isSold ? " · продано" : ""}`} aria-label={`${rowLabel(rowIndex)} ряд, место ${seatIndex + 1}${isBlocked ? ", недоступно" : isSold ? ", продано" : isSelected ? ", выбрано" : ", свободно"}`} disabled={isBlocked || isSold} onClick={() => toggleSeat(code)} className={`seat ${isBlocked ? "blocked" : isSold ? "sold" : isSelected ? "chosen" : "available"}`}>
                              {isBlocked ? "×" : seatIndex + 1}
                            </button>;
                          })}
                        </div>)}
                      </div></div>
                      <div className="map-legend"><span><i className="legend-seat available-legend" />Свободно</span><span><i className="legend-seat chosen-legend" />Выбрано</span><span><i className="legend-seat sold-legend" />Продано</span><span><i className="legend-seat blocked-legend" />Закрыто</span></div>
                      <div className="seat-panel-footer"><span><Icon name="lock" size={14} />Кликните по свободному месту, чтобы добавить его в чек</span><span>Цена билета: <strong>{money(activeEvent.price)}</strong></span></div>
                    </section>
                    <div className="sale-footnote"><Icon name="receipt" size={15} /><span>Продажа фиксируется в журнале кассы и сразу отображается в сводке администратора.</span></div>
                  </div>

                  <aside className="receipt-panel">
                    <div className="receipt-topline"><div><span className="receipt-label">КАССОВЫЙ ЧЕК</span><strong>№ {String(data.summary.salesCount + 1).padStart(5, "0")}</strong></div><span className="receipt-status">НОВЫЙ</span></div>
                    <div className="receipt-cashier"><span className="avatar small-avatar">{userInitials}</span><div><small>Кассир</small><strong>{currentCashier}</strong></div><span className="receipt-clock">{new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date())}</span></div>
                    <div className="receipt-total"><div className="total-caption">ИТОГО К ОПЛАТЕ</div><strong>{money(receiptTotal)}</strong><div className="receipt-subtotal"><span>Билетов в чеке</span><strong>{selectedSeats.length}</strong></div><div className="receipt-subtotal"><span>Без скидки</span><span>{money(receiptTotal)}</span></div></div>
                    <div className="receipt-ticket-heading"><span>СОСТАВ ЧЕКА</span><span>{selectedSeats.length} шт.</span></div>
                    <div className="receipt-ticket-list">
                      {selectedSeats.length === 0 ? <div className="receipt-empty"><div className="receipt-empty-icon"><Icon name="ticket" size={21} /></div><span>Выберите места<br />на схеме зала</span></div> : selectedSeats.slice().sort((a, b) => a.localeCompare(b, "ru")).map((code) => <div className="receipt-ticket" key={code}><span className="ticket-seat-mark"><Icon name="ticket" size={14} /></span><div className="ticket-seat-name"><strong>{activeEvent.title}</strong><small>{code.match(/^[A-Z]+/)?.[0]} ряд · место {code.match(/\d+$/)?.[0]}</small></div><strong className="ticket-price">{money(activeEvent.price)}</strong><button aria-label={`Убрать место ${code}`} onClick={() => toggleSeat(code)} className="remove-ticket"><Icon name="close" size={13} /></button></div>)}
                    </div>
                    <div className="payment-area"><div className="payment-label">СПОСОБ ОПЛАТЫ</div><div className="payment-methods"><button className={paymentMethod === "cash" ? "payment-choice selected" : "payment-choice"} onClick={() => setPaymentMethod("cash")}><Icon name="money" size={17} /><span>Наличные</span><small>F6</small></button><button className={paymentMethod === "card" ? "payment-choice selected" : "payment-choice"} onClick={() => setPaymentMethod("card")}><Icon name="card" size={17} /><span>Карта</span><small>F7</small></button></div>
                      {paymentMethod === "cash" ? <div className="cash-fields"><label htmlFor="cash-input">Внесено наличными</label><div className="cash-input-wrap"><input id="cash-input" type="number" min="0" step="100" value={cashReceived || (receiptTotal ? String(receiptTotal) : "")} onChange={(event) => setCashReceived(event.target.value)} placeholder="0" /><span>₽</span></div><div className="change-line"><span>Сдача</span><strong>{money(changeAmount)}</strong></div><div className="quick-cash"><button onClick={() => setCashReceived(String(receiptTotal))}>Без сдачи</button><button onClick={() => setCashReceived(String(Math.ceil(receiptTotal / 500) * 500))}>+ до 500</button></div></div> : <div className="card-approval"><span className="card-check"><Icon name="check" size={15} /></span><span>Оплата картой · терминал готов</span><strong>{money(receiptTotal)}</strong></div>}
                    </div>
                    <div className="receipt-actions"><button className="checkout-button" disabled={savingSale || selectedSeats.length === 0 || (paymentMethod === "cash" && paidAmount < receiptTotal)} onClick={() => void completeSale()}>{savingSale ? <span className="loading-spinner light-spinner" /> : <Icon name="check" size={19} />}<span>{savingSale ? "Оформляем…" : "Пробить чек"}</span><kbd>Enter</kbd></button><button className="cancel-check" onClick={() => { setSelectedSeats([]); setCashReceived(""); }}><Icon name="close" size={14} />Отменить чек</button></div>
                    <div className="receipt-bottom"><span>Безопасная кассовая операция</span><Icon name="lock" size={13} /></div>
                  </aside>
                </div>
              )}
            </>
          )}

          {section === "overview" && (
            <>
              <div className="page-heading">
                <div><div className="eyebrow">{role === "admin" ? "ПАНЕЛЬ УПРАВЛЕНИЯ" : "РАБОЧЕЕ МЕСТО БИЛЕТЁРА"}</div><h1>{role === "admin" ? "Сводка кассы" : "Моя смена"}</h1><p>{role === "admin" ? "Продажи, загрузка залов и последние операции" : "Ваши продажи и состояние текущей смены"}</p></div>
                <div className="heading-actions"><span className="updated-at"><Icon name="clock" size={15} />Обновлено только что</span><button className="classic-button" onClick={() => void loadData()}><Icon name="refresh" size={15} />Обновить</button></div>
              </div>
              <div className="metrics-grid">
                <div className="metric-card yellow-metric"><div className="metric-icon"><Icon name="money" size={18} /></div><div className="metric-label">Выручка {role === "admin" ? "всего" : "за смену"}</div><strong>{money(allSalesTotal)}</strong><small><span className="metric-trend">↗</span> По всем оформленным чекам</small></div>
                <div className="metric-card"><div className="metric-icon blue-icon"><Icon name="ticket" size={18} /></div><div className="metric-label">Продано билетов</div><strong>{role === "admin" ? data.summary.ticketsCount : clerkSales.reduce((sum, sale) => sum + sale.ticketsCount, 0)}</strong><small>Зафиксировано в базе кассы</small></div>
                <div className="metric-card"><div className="metric-icon green-icon"><Icon name="calendar" size={18} /></div><div className="metric-label">Мероприятий в афише</div><strong>{data.events.length}</strong><small>{data.halls.length} {data.halls.length === 1 ? "зал" : "зала"} в системе</small></div>
                <div className="metric-card"><div className="metric-icon violet-icon"><Icon name="receipt" size={18} /></div><div className="metric-label">Оформлено чеков</div><strong>{role === "admin" ? data.summary.salesCount : clerkSales.length}</strong><small>Кассовые операции</small></div>
              </div>
              <div className="dashboard-grid">
                <section className="dashboard-panel chart-panel">
                  <div className="section-title-row"><div><h2>Продажи за 7 дней</h2><p>Выручка по дням, ₽</p></div><span className="chart-period">ПОСЛЕДНЯЯ НЕДЕЛЯ</span></div>
                  <div className="chart-summary"><strong>{money(chartRows.reduce((sum, row) => sum + row.amount, 0))}</strong><span>за выбранный период</span></div>
                  <div className="bar-chart" role="img" aria-label="График продаж за последние семь дней">
                    {chartRows.map((row, index) => <div className="bar-column" key={row.dateKey}><div className="bar-value">{row.amount > 0 ? new Intl.NumberFormat("ru-RU", { notation: "compact", maximumFractionDigits: 1 }).format(row.amount) : ""}</div><div className="bar-track"><div className={`bar-fill ${index === chartRows.length - 1 ? "today-bar" : ""}`} style={{ height: `${row.amount ? Math.max(8, (row.amount / chartMax) * 100) : 3}%` }} /></div><span>{row.label}</span></div>)}
                  </div>
                </section>
                <section className="dashboard-panel occupancy-panel">
                  <div className="section-title-row"><div><h2>Загрузка мероприятий</h2><p>Свободные места по сеансам</p></div><span className="mini-icon"><Icon name="grid" size={17} /></span></div>
                  <div className="occupancy-list">{data.events.slice(0, 4).map((event) => {
                    const hall = data.halls.find((item) => item.id === event.hallId);
                    const capacity = hall ? hall.rows * hall.seatsPerRow - hall.blockedSeats.length : 0;
                    const sold = data.tickets.filter((ticket) => ticket.eventId === event.id).length;
                    const percent = capacity ? Math.round((sold / capacity) * 100) : 0;
                    return <div className="occupancy-row" key={event.id}><div className="occupancy-event"><div><strong>{event.title}</strong><small>{formatEventDate(event.eventDate)} · {event.hallName}</small></div><span>{sold}/{capacity}</span></div><div className="progress-line"><span style={{ width: `${percent}%` }} /></div></div>;
                  })}{data.events.length === 0 && <div className="empty-inline">Пока нет мероприятий в афише</div>}</div>
                  {role === "admin" && <button className="text-link" onClick={() => setSection("events")}>Управление афишей <Icon name="arrow" size={14} /></button>}
                </section>
              </div>
              <section className="dashboard-panel activity-panel">
                <div className="section-title-row"><div><h2>Последние продажи</h2><p>Журнал кассовых операций</p></div><span className="activity-count">{clerkSales.length} операций</span></div>
                {clerkSales.length === 0 ? <div className="empty-inline spacious-empty"><Icon name="receipt" size={22} /><span>Продаж пока нет. Оформите первый чек в кассе.</span><button className="classic-button" onClick={() => setSection("sale")}>Перейти в кассу <Icon name="arrow" size={14} /></button></div> : <div className="table-scroll"><table className="data-table"><thead><tr><th>ЧЕК</th><th>МЕРОПРИЯТИЕ</th><th>КАССИР</th><th>ОПЛАТА</th><th>ВРЕМЯ</th><th className="align-right">СУММА</th></tr></thead><tbody>{clerkSales.slice(0, 8).map((sale) => <tr key={sale.id}><td><span className="receipt-number">#{String(sale.id).padStart(5, "0")}</span><small>{sale.ticketsCount} {sale.ticketsCount === 1 ? "билет" : "билета"}</small></td><td><strong>{sale.eventTitle}</strong></td><td>{sale.cashier}</td><td><span className="payment-pill"><Icon name={sale.paymentMethod === "card" ? "card" : "money"} size={13} />{sale.paymentMethod === "card" ? "Карта" : "Наличные"}</span></td><td>{formatEventDate(sale.createdAt, false)}</td><td className="align-right"><strong>{money(sale.total)}</strong></td></tr>)}</tbody></table></div>}
              </section>
              {role === "admin" && <div className="quick-actions"><button className="quick-action" onClick={() => openEventForm()}><span className="quick-action-icon"><Icon name="calendar" size={19} /></span><span><strong>Создать мероприятие</strong><small>Добавить сеанс в афишу</small></span><Icon name="arrow" size={16} /></button><button className="quick-action" onClick={() => openHallForm()}><span className="quick-action-icon hall-quick-icon"><Icon name="grid" size={19} /></span><span><strong>Добавить зал</strong><small>Настроить места и ряды</small></span><Icon name="arrow" size={16} /></button></div>}
            </>
          )}

          {section === "events" && role === "admin" && (
            <>
              <div className="page-heading"><div><div className="eyebrow">СПРАВОЧНИК · РАСПИСАНИЕ</div><h1>Мероприятия</h1><p>Афиша театра и управление сеансами</p></div><div className="heading-actions"><span className="table-count">{data.events.length} в афише</span><button className="classic-button primary" onClick={() => openEventForm()}><Icon name="plus" size={16} />Создать мероприятие</button></div></div>
              {data.events.length === 0 ? <div className="empty-state"><Icon name="calendar" size={28} /><h2>Афиша пока пуста</h2><p>Добавьте первое мероприятие, чтобы открыть продажи.</p><button className="classic-button primary" onClick={() => openEventForm()}><Icon name="plus" size={16} />Создать мероприятие</button></div> : <section className="management-panel"><div className="table-toolbar"><div className="table-toolbar-title"><Icon name="calendar" size={17} /><strong>Расписание показов</strong></div><div className="table-toolbar-right"><span className="live-dot" />Данные обновляются автоматически</div></div><div className="table-scroll"><table className="data-table event-table"><thead><tr><th>МЕРОПРИЯТИЕ</th><th>ДАТА И ВРЕМЯ</th><th>ЗАЛ</th><th>ЦЕНА БИЛЕТА</th><th>ПРОДАНО</th><th>СТАТУС</th><th></th></tr></thead><tbody>{data.events.map((event) => {
                const hall = data.halls.find((item) => item.id === event.hallId);
                const capacity = hall ? hall.rows * hall.seatsPerRow - hall.blockedSeats.length : 0;
                const sold = data.tickets.filter((ticket) => ticket.eventId === event.id).length;
                return <tr key={event.id}><td><div className="event-name-cell"><span className={`event-art art-${event.genre === "Балет" ? "ballet" : event.genre === "Комедия" ? "comedy" : "drama"}`}><Icon name="theatre" size={17} /></span><div><strong>{event.title}</strong><small>{event.genre}</small></div></div></td><td><strong>{formatEventDate(event.eventDate)}</strong></td><td>{event.hallName}</td><td><strong>{money(event.price)}</strong></td><td><div className="sold-cell"><strong>{sold}</strong><span>/ {capacity}</span></div></td><td><span className="status-pill"><i />В продаже</span></td><td><button className="icon-button table-edit" aria-label={`Редактировать ${event.title}`} title="Редактировать мероприятие" onClick={() => openEventForm(event)}><Icon name="edit" size={15} /></button></td></tr>;
              })}</tbody></table></div><div className="table-footer"><span>Показано мероприятий: {data.events.length}</span><span><Icon name="lock" size={13} />Изменения сразу сохраняются в базе</span></div></section>}
            </>
          )}

          {section === "halls" && role === "admin" && (
            <>
              <div className="page-heading"><div><div className="eyebrow">СПРАВОЧНИК · СХЕМЫ ЗАЛОВ</div><h1>Залы театра</h1><p>Создавайте залы и редактируйте схему зрительских мест</p></div><div className="heading-actions"><span className="table-count">{data.halls.length} {data.halls.length === 1 ? "зал" : "зала"}</span><button className="classic-button primary" onClick={() => openHallForm()}><Icon name="plus" size={16} />Добавить зал</button></div></div>
              {data.halls.length === 0 ? <div className="empty-state"><Icon name="grid" size={28} /><h2>Залов пока нет</h2><p>Добавьте зал, задайте количество рядов и отметьте закрытые места.</p><button className="classic-button primary" onClick={() => openHallForm()}><Icon name="plus" size={16} />Добавить зал</button></div> : <div className="hall-cards">{data.halls.map((hall, index) => {
                const hallEventIds = new Set(data.events.filter((event) => event.hallId === hall.id).map((event) => event.id));
                const soldCount = data.tickets.filter((ticket) => hallEventIds.has(ticket.eventId)).length;
                const capacity = hall.rows * hall.seatsPerRow - hall.blockedSeats.length;
                return <article className="hall-card" key={hall.id}><div className={`hall-card-banner hall-banner-${index % 3}`}><div className="hall-watermark"><Icon name="grid" size={56} /></div><span className="hall-chip">ЗАЛ №{String(index + 1).padStart(2, "0")}</span><div className="hall-banner-title"><span>{hall.name}</span><small>ТЕАТРАЛЬНОЕ ПРОСТРАНСТВО</small></div><span className="hall-banner-seats"><Icon name="ticket" size={14} />{capacity} мест</span></div><div className="hall-card-content"><div className="hall-specs"><div><span>РЯДОВ</span><strong>{hall.rows}</strong></div><div><span>МЕСТ В РЯДУ</span><strong>{hall.seatsPerRow}</strong></div><div><span>ЗАКРЫТО</span><strong>{hall.blockedSeats.length}</strong></div></div><div className="hall-card-events"><span className="hall-events-icon"><Icon name="calendar" size={15} /></span><span><strong>{data.events.filter((event) => event.hallId === hall.id).length}</strong> мероприятий в афише</span><span className="hall-spacer" /><span className="hall-sold-count">{soldCount} продано</span></div><button className="hall-edit-button" onClick={() => openHallForm(hall)}><Icon name="edit" size={15} />Открыть редактор зала<Icon name="arrow" size={15} /></button></div></article>;
              })}<button className="add-hall-card" onClick={() => openHallForm()}><span className="add-hall-icon"><Icon name="plus" size={22} /></span><strong>Добавить новый зал</strong><small>Настройте схему и количество мест</small></button></div>}
              <div className="hall-editor-hint"><span className="hint-icon"><Icon name="settings" size={16} /></span><span><strong>Редактор зала</strong><small>Закрытые места нельзя продать. Схему с уже проданными местами нельзя уменьшить или заблокировать.</small></span></div>
            </>
          )}

          {role === "clerk" && (section === "events" || section === "halls") && <div className="empty-state"><Icon name="lock" size={28} /><h2>Раздел доступен администратору</h2><p>Переключите роль пользователя на «Администратор», чтобы управлять афишей и залами.</p><button className="classic-button primary" onClick={() => changeRole("admin")}>Переключить роль</button></div>}
        </section>
      </div>

      <footer className="status-bar"><span className="status-left"><span className="status-led" /><Icon name="home" size={14} />Подключение к PostgreSQL: активно</span><span>Текущие продажи: {data.summary.salesCount} <span className="status-divider">|</span> Продано билетов: {data.summary.ticketsCount}</span><span className="status-right">Театр.Касса · рабочая версия <span className="status-separator">|</span> {new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date())}</span></footer>

      {notice && <div className={`toast ${notice.kind}`} role="status"><span className="toast-icon"><Icon name={notice.kind === "success" ? "check" : "bell"} size={17} /></span><span>{notice.message}</span><button aria-label="Закрыть сообщение" onClick={() => setNotice(null)}><Icon name="close" size={15} /></button></div>}

      {modal === "event" && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}><section className="modal-card event-modal" role="dialog" aria-modal="true" aria-labelledby="event-modal-title"><div className="modal-header"><div><div className="eyebrow">АФИША ТЕАТРА</div><h2 id="event-modal-title">{editingEventId ? "Редактировать мероприятие" : "Новое мероприятие"}</h2><p>Заполните карточку показа и сохраните данные</p></div><button className="modal-close" onClick={() => setModal(null)} aria-label="Закрыть"><Icon name="close" size={19} /></button></div><form onSubmit={(event) => void saveEvent(event)}><div className="form-body"><label className="form-field form-full"><span>Название мероприятия <i>*</i></span><input autoFocus required maxLength={120} value={eventForm.title} onChange={(event) => setEventForm({ ...eventForm, title: event.target.value })} placeholder="Например, Вишнёвый сад" /></label><div className="form-grid-two"><label className="form-field"><span>Жанр</span><select value={eventForm.genre} onChange={(event) => setEventForm({ ...eventForm, genre: event.target.value })}><option>Спектакль</option><option>Драма</option><option>Комедия</option><option>Балет</option><option>Опера</option><option>Мюзикл</option><option>Концерт</option><option>Детский спектакль</option></select></label><label className="form-field"><span>Зал <i>*</i></span><select required value={eventForm.hallId} onChange={(event) => setEventForm({ ...eventForm, hallId: event.target.value })}><option value="" disabled>Выберите зал</option>{data.halls.map((hall) => <option value={hall.id} key={hall.id}>{hall.name}</option>)}</select></label></div><div className="form-grid-two"><label className="form-field"><span>Дата и время <i>*</i></span><input type="datetime-local" required value={eventForm.eventDate} onChange={(event) => setEventForm({ ...eventForm, eventDate: event.target.value })} /></label><label className="form-field"><span>Цена билета, ₽ <i>*</i></span><div className="input-suffix"><input type="number" min="1" max="1000000" step="50" required value={eventForm.price} onChange={(event) => setEventForm({ ...eventForm, price: event.target.value })} /><span>₽</span></div></label></div><label className="form-field form-full"><span>Краткое описание</span><textarea rows={3} maxLength={500} value={eventForm.description} onChange={(event) => setEventForm({ ...eventForm, description: event.target.value })} placeholder="О чём этот спектакль — несколько предложений" /></label><div className="form-info"><Icon name="check" size={15} /><span>Мероприятие появится в списке кассы сразу после сохранения.</span></div></div><div className="modal-footer"><button type="button" className="classic-button" onClick={() => setModal(null)}>Отмена</button><button type="submit" className="classic-button primary" disabled={savingForm || data.halls.length === 0}>{savingForm ? <span className="loading-spinner" /> : <Icon name="check" size={16} />}{savingForm ? "Сохраняем…" : editingEventId ? "Сохранить изменения" : "Создать мероприятие"}</button></div></form></section></div>}

      {modal === "hall" && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setModal(null); }}><section className="modal-card hall-modal" role="dialog" aria-modal="true" aria-labelledby="hall-modal-title"><div className="modal-header"><div><div className="eyebrow">КОНСТРУКТОР ЗАЛА</div><h2 id="hall-modal-title">{editingHallId ? "Редактор зала" : "Новый зал"}</h2><p>Настройте ряды и обозначьте закрытые места</p></div><button className="modal-close" onClick={() => setModal(null)} aria-label="Закрыть"><Icon name="close" size={19} /></button></div><form onSubmit={(event) => void saveHall(event)}><div className="form-body hall-form-body"><label className="form-field form-full"><span>Название зала <i>*</i></span><input autoFocus required maxLength={80} value={hallForm.name} onChange={(event) => setHallForm({ ...hallForm, name: event.target.value })} placeholder="Например, Большой зал" /></label><div className="form-grid-two"><label className="form-field"><span>Количество рядов</span><div className="stepper-field"><input type="number" min="2" max="20" value={hallForm.rows} onChange={(event) => setHallForm({ ...hallForm, rows: Number(event.target.value) })} /><span>рядов</span></div></label><label className="form-field"><span>Мест в ряду</span><div className="stepper-field"><input type="number" min="2" max="24" value={hallForm.seatsPerRow} onChange={(event) => setHallForm({ ...hallForm, seatsPerRow: Number(event.target.value) })} /><span>мест</span></div></label></div><div className="editor-toolbar"><div><strong>Редактор схемы мест</strong><small>Нажмите на кресло, чтобы закрыть или открыть его</small></div><span className="editor-count">{hallForm.rows * hallForm.seatsPerRow - hallForm.blockedSeats.length} мест</span></div><div className="editor-stage"><span>СЦЕНА</span></div><div className="editor-map-wrap"><div className="editor-map" style={{ gridTemplateColumns: `26px repeat(${Math.min(hallForm.seatsPerRow, 24)}, minmax(19px, 1fr))` }}><span className="editor-corner">РЯД</span>{Array.from({ length: hallForm.seatsPerRow }, (_, index) => <span className="editor-column-number" key={`col-${index}`}>{index + 1}</span>)}{Array.from({ length: hallForm.rows }, (_, rowIndex) => <div key={`editor-row-${rowIndex}`} style={{ display: "contents" }}><span className="editor-row-letter">{rowLabel(rowIndex)}</span>{Array.from({ length: hallForm.seatsPerRow }, (_, seatIndex) => {
                const code = seatCode(rowIndex, seatIndex + 1);
                const isBlocked = hallForm.blockedSeats.includes(code);
                const isProtected = protectedSeats.has(code);
                return <button key={code} type="button" title={isProtected ? `${code} — место уже продано` : `${code} — ${isBlocked ? "закрыто, нажмите чтобы открыть" : "открыто, нажмите чтобы закрыть"}`} className={`editor-seat ${isBlocked ? "editor-blocked" : isProtected ? "editor-protected" : ""}`} disabled={isProtected} onClick={() => toggleBlockedSeat(code)}>{isBlocked ? "×" : seatIndex + 1}</button>;
              })}</div>)}</div></div><div className="editor-legend"><span><i className="legend-seat available-legend" />Доступно для продажи</span><span><i className="legend-seat blocked-legend" />Закрыто</span>{editingHallId && <span><i className="legend-seat sold-legend" />Есть проданный билет</span>}</div>{editingHallId && protectedSeats.size > 0 && <div className="form-info warning-info"><Icon name="lock" size={15} /><span>Проданные места защищены от изменения схемы.</span></div>}</div><div className="modal-footer"><button type="button" className="classic-button" onClick={() => setModal(null)}>Отмена</button><button type="submit" className="classic-button primary" disabled={savingForm}>{savingForm ? <span className="loading-spinner" /> : <Icon name="check" size={16} />}{savingForm ? "Сохраняем…" : editingHallId ? "Сохранить схему" : "Создать зал"}</button></div></form></section></div>}
    </main>
  );
}
