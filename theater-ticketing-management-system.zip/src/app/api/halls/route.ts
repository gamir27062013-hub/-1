import { db } from "@/db";
import { halls } from "@/db/schema";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      name?: unknown;
      rows?: unknown;
      seatsPerRow?: unknown;
    };
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const rows = Number(body.rows);
    const seatsPerRow = Number(body.seatsPerRow);

    if (!name || name.length > 80) {
      return NextResponse.json({ error: "Укажите название зала до 80 символов" }, { status: 400 });
    }
    if (!Number.isInteger(rows) || rows < 2 || rows > 20) {
      return NextResponse.json({ error: "В зале должно быть от 2 до 20 рядов" }, { status: 400 });
    }
    if (!Number.isInteger(seatsPerRow) || seatsPerRow < 2 || seatsPerRow > 24) {
      return NextResponse.json({ error: "В ряду должно быть от 2 до 24 мест" }, { status: 400 });
    }

    const [hall] = await db
      .insert(halls)
      .values({ name, rows, seatsPerRow, blockedSeats: [] })
      .returning();

    return NextResponse.json(hall, { status: 201 });
  } catch (error) {
    console.error("Failed to create hall:", error);
    return NextResponse.json({ error: "Не удалось создать зал" }, { status: 500 });
  }
}
