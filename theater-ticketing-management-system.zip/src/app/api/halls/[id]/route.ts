import { db } from "@/db";
import { events, halls, tickets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type RouteContext = { params: Promise<{ id: string }> };

function seatPosition(code: string) {
  const match = /^([A-Z]+)(\d+)$/.exec(code);
  if (!match) return null;
  let rowNumber = 0;
  for (const letter of match[1]) rowNumber = rowNumber * 26 + letter.charCodeAt(0) - 64;
  return { row: rowNumber - 1, seat: Number(match[2]) };
}

export async function PATCH(request: Request, context: RouteContext) {
  try {
    const { id: idValue } = await context.params;
    const id = Number(idValue);
    if (!Number.isInteger(id) || id < 1) {
      return NextResponse.json({ error: "Некорректный номер зала" }, { status: 400 });
    }

    const [current] = await db.select().from(halls).where(eq(halls.id, id)).limit(1);
    if (!current) return NextResponse.json({ error: "Зал не найден" }, { status: 404 });

    const body = (await request.json()) as {
      name?: unknown;
      rows?: unknown;
      seatsPerRow?: unknown;
      blockedSeats?: unknown;
    };
    const name = typeof body.name === "string" ? body.name.trim() : current.name;
    const rows = Number(body.rows ?? current.rows);
    const seatsPerRow = Number(body.seatsPerRow ?? current.seatsPerRow);
    const blockedSeats = Array.isArray(body.blockedSeats)
      ? [...new Set(body.blockedSeats.filter((seat): seat is string => typeof seat === "string"))]
      : current.blockedSeats;

    if (!name || name.length > 80) {
      return NextResponse.json({ error: "Укажите название зала до 80 символов" }, { status: 400 });
    }
    if (!Number.isInteger(rows) || rows < 2 || rows > 20) {
      return NextResponse.json({ error: "В зале должно быть от 2 до 20 рядов" }, { status: 400 });
    }
    if (!Number.isInteger(seatsPerRow) || seatsPerRow < 2 || seatsPerRow > 24) {
      return NextResponse.json({ error: "В ряду должно быть от 2 до 24 мест" }, { status: 400 });
    }
    if (blockedSeats.length > rows * seatsPerRow) {
      return NextResponse.json({ error: "Слишком много заблокированных мест" }, { status: 400 });
    }
    if (blockedSeats.some((seat) => {
      const position = seatPosition(seat);
      return !position || position.row >= rows || position.seat < 1 || position.seat > seatsPerRow;
    })) {
      return NextResponse.json({ error: "Проверьте номера заблокированных мест" }, { status: 400 });
    }

    const soldSeats = await db
      .select({ seatCode: tickets.seatCode })
      .from(tickets)
      .innerJoin(events, eq(tickets.eventId, events.id))
      .where(eq(events.hallId, id));
    const occupied = soldSeats.find(({ seatCode }) => {
      const position = seatPosition(seatCode);
      return (
        !position ||
        position.row >= rows ||
        position.seat > seatsPerRow ||
        blockedSeats.includes(seatCode)
      );
    });

    if (occupied) {
      return NextResponse.json(
        { error: `Место ${occupied.seatCode} уже продано. Сначала перенесите или верните билет.` },
        { status: 409 },
      );
    }

    const [updatedHall] = await db
      .update(halls)
      .set({ name, rows, seatsPerRow, blockedSeats })
      .where(eq(halls.id, id))
      .returning();

    return NextResponse.json(updatedHall);
  } catch (error) {
    console.error("Failed to update hall:", error);
    return NextResponse.json({ error: "Не удалось сохранить зал" }, { status: 500 });
  }
}
