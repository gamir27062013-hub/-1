import { db } from "@/db";
import { events, halls, sales, tickets } from "@/db/schema";
import { and, eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";

function seatPosition(code: string) {
  const match = /^([A-Z]+)(\d+)$/.exec(code);
  if (!match) return null;
  let rowNumber = 0;
  for (const letter of match[1]) rowNumber = rowNumber * 26 + letter.charCodeAt(0) - 64;
  return { row: rowNumber - 1, seat: Number(match[2]) };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      eventId?: unknown;
      seatCodes?: unknown;
      paymentMethod?: unknown;
      cashier?: unknown;
    };
    const eventId = Number(body.eventId);
    const seatCodes = Array.isArray(body.seatCodes)
      ? [...new Set(body.seatCodes.filter((seat): seat is string => typeof seat === "string"))]
      : [];
    const paymentMethod = body.paymentMethod === "card" ? "card" : body.paymentMethod === "cash" ? "cash" : "";
    const cashier = typeof body.cashier === "string" && body.cashier.trim() ? body.cashier.trim() : "Кассир";

    if (!Number.isInteger(eventId) || eventId < 1) {
      return NextResponse.json({ error: "Выберите мероприятие" }, { status: 400 });
    }
    if (seatCodes.length < 1 || seatCodes.length > 24) {
      return NextResponse.json({ error: "Выберите от 1 до 24 мест" }, { status: 400 });
    }
    if (!paymentMethod) return NextResponse.json({ error: "Выберите способ оплаты" }, { status: 400 });

    const result = await db.transaction(async (tx) => {
      const [event] = await tx.select().from(events).where(eq(events.id, eventId)).limit(1);
      if (!event || event.status !== "active") throw new Error("EVENT_NOT_AVAILABLE");

      const [hall] = await tx.select().from(halls).where(eq(halls.id, event.hallId)).limit(1);
      if (!hall) throw new Error("HALL_NOT_FOUND");

      const invalidSeat = seatCodes.find((code) => {
        const position = seatPosition(code);
        return (
          !position ||
          position.row < 0 ||
          position.row >= hall.rows ||
          position.seat < 1 ||
          position.seat > hall.seatsPerRow ||
          hall.blockedSeats.includes(code)
        );
      });
      if (invalidSeat) throw new Error("INVALID_SEAT");

      const occupied = await tx
        .select({ seatCode: tickets.seatCode })
        .from(tickets)
        .where(and(eq(tickets.eventId, eventId), inArray(tickets.seatCode, seatCodes)));
      if (occupied.length > 0) throw new Error("SEAT_ALREADY_SOLD");

      const total = event.price * seatCodes.length;
      const [sale] = await tx
        .insert(sales)
        .values({ eventId, cashier, paymentMethod, total, ticketsCount: seatCodes.length })
        .returning();
      await tx.insert(tickets).values(
        seatCodes.map((seatCode) => ({ saleId: sale.id, eventId, seatCode, price: event.price })),
      );

      return { sale, eventTitle: event.title, price: event.price };
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "EVENT_NOT_AVAILABLE") {
      return NextResponse.json({ error: "Мероприятие больше не доступно" }, { status: 404 });
    }
    if (message === "HALL_NOT_FOUND") return NextResponse.json({ error: "Зал не найден" }, { status: 404 });
    if (message === "INVALID_SEAT") return NextResponse.json({ error: "Выбрано недоступное место" }, { status: 400 });
    if (message === "SEAT_ALREADY_SOLD" || (error as { code?: string })?.code === "23505") {
      return NextResponse.json({ error: "Одно из мест уже продано. Обновите схему зала." }, { status: 409 });
    }
    console.error("Failed to create ticket sale:", error);
    return NextResponse.json({ error: "Не удалось оформить продажу" }, { status: 500 });
  }
}
