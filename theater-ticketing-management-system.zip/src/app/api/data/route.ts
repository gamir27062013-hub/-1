import { db } from "@/db";
import { events, halls, sales, tickets } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function localDateAfter(days: number, hour: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  date.setHours(hour, 0, 0, 0);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
}

async function ensureDemoData() {
  let existingHalls = await db.select().from(halls).orderBy(halls.id);

  if (existingHalls.length === 0) {
    existingHalls = await db
      .insert(halls)
      .values([
        { name: "Большой зал", rows: 9, seatsPerRow: 12, blockedSeats: ["A1", "A12"] },
        { name: "Малая сцена", rows: 6, seatsPerRow: 10, blockedSeats: ["A1", "A10"] },
      ])
      .returning();
  }

  const existingEvents = await db.select({ id: events.id }).from(events).limit(1);

  if (existingEvents.length === 0 && existingHalls.length > 0) {
    const mainHall = existingHalls[0];
    const smallHall = existingHalls[1] ?? existingHalls[0];

    await db.insert(events).values([
      {
        title: "Щелкунчик",
        description: "Сказочный балет в двух действиях по мотивам сказки Э. Т. А. Гофмана.",
        genre: "Балет",
        eventDate: localDateAfter(1, 19),
        hallId: mainHall.id,
        price: 1800,
      },
      {
        title: "Гамлет",
        description: "Трагедия о выборе, правде и цене сомнения.",
        genre: "Драма",
        eventDate: localDateAfter(2, 18),
        hallId: mainHall.id,
        price: 1600,
      },
      {
        title: "Служебный роман",
        description: "Лёгкая комедия о любви, которая находит дорогу в самый обычный день.",
        genre: "Комедия",
        eventDate: localDateAfter(3, 19),
        hallId: smallHall.id,
        price: 1200,
      },
    ]);
  }
}

export async function GET() {
  try {
    await ensureDemoData();

    const [hallRows, eventRows, ticketRows, activityRows, summaryRows] = await Promise.all([
      db.select().from(halls).orderBy(halls.id),
      db
        .select({
          id: events.id,
          title: events.title,
          description: events.description,
          genre: events.genre,
          eventDate: events.eventDate,
          hallId: events.hallId,
          hallName: halls.name,
          price: events.price,
          status: events.status,
        })
        .from(events)
        .innerJoin(halls, eq(events.hallId, halls.id))
        .orderBy(events.eventDate),
      db.select({ eventId: tickets.eventId, seatCode: tickets.seatCode }).from(tickets),
      db
        .select({
          id: sales.id,
          eventId: sales.eventId,
          eventTitle: events.title,
          cashier: sales.cashier,
          paymentMethod: sales.paymentMethod,
          total: sales.total,
          ticketsCount: sales.ticketsCount,
          createdAt: sales.createdAt,
        })
        .from(sales)
        .innerJoin(events, eq(sales.eventId, events.id))
        .orderBy(desc(sales.createdAt))
        .limit(40),
      db
        .select({
          revenue: sql<number>`coalesce(sum(${sales.total}), 0)`,
          ticketsCount: sql<number>`coalesce(sum(${sales.ticketsCount}), 0)`,
          salesCount: sql<number>`count(*)`,
        })
        .from(sales),
    ]);

    const summary = summaryRows[0];

    return NextResponse.json({
      halls: hallRows,
      events: eventRows,
      tickets: ticketRows,
      sales: activityRows,
      summary: {
        revenue: Number(summary?.revenue ?? 0),
        ticketsCount: Number(summary?.ticketsCount ?? 0),
        salesCount: Number(summary?.salesCount ?? 0),
      },
    });
  } catch (error) {
    console.error("Failed to load theatre data:", error);
    return NextResponse.json({ error: "Не удалось загрузить данные кассы" }, { status: 500 });
  }
}
