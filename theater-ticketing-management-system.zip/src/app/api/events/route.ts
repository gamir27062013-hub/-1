import { db } from "@/db";
import { events, halls } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type ParsedEvent =
  | { error: string; value?: never }
  | {
      error?: never;
      value: { title: string; genre: string; description: string; eventDate: string; hallId: number; price: number };
    };

function parseEvent(body: Record<string, unknown>): ParsedEvent {
  const title = typeof body.title === "string" ? body.title.trim() : "";
  const genre = typeof body.genre === "string" && body.genre.trim() ? body.genre.trim() : "Спектакль";
  const description = typeof body.description === "string" ? body.description.trim() : "";
  const eventDate = typeof body.eventDate === "string" ? body.eventDate.trim() : "";
  const hallId = Number(body.hallId);
  const price = Number(body.price);

  if (!title || title.length > 120) return { error: "Укажите название мероприятия до 120 символов" };
  if (!eventDate || Number.isNaN(Date.parse(eventDate))) return { error: "Укажите корректные дату и время" };
  if (!Number.isInteger(hallId) || hallId < 1) return { error: "Выберите зал" };
  if (!Number.isInteger(price) || price < 1 || price > 1_000_000) {
    return { error: "Цена должна быть от 1 до 1 000 000 ₽" };
  }
  return { value: { title, genre, description, eventDate, hallId, price } };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const parsed = parseEvent(body);
    if (!parsed.value) return NextResponse.json({ error: parsed.error ?? "Проверьте данные" }, { status: 400 });
    const value = parsed.value;

    const [hall] = await db.select({ id: halls.id }).from(halls).where(eq(halls.id, value.hallId)).limit(1);
    if (!hall) return NextResponse.json({ error: "Выбранный зал не найден" }, { status: 404 });

    const [event] = await db.insert(events).values(value).returning();
    return NextResponse.json(event, { status: 201 });
  } catch (error) {
    console.error("Failed to create event:", error);
    return NextResponse.json({ error: "Не удалось создать мероприятие" }, { status: 500 });
  }
}
