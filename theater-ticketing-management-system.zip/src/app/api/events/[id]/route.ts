import { db } from "@/db";
import { events, halls, tickets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  try {
    const { id: idValue } = await context.params;
    const id = Number(idValue);
    if (!Number.isInteger(id) || id < 1) {
      return NextResponse.json({ error: "Некорректный номер мероприятия" }, { status: 400 });
    }

    const [current] = await db.select().from(events).where(eq(events.id, id)).limit(1);
    if (!current) return NextResponse.json({ error: "Мероприятие не найдено" }, { status: 404 });

    const body = (await request.json()) as Record<string, unknown>;
    const title = typeof body.title === "string" ? body.title.trim() : current.title;
    const genre = typeof body.genre === "string" && body.genre.trim() ? body.genre.trim() : current.genre;
    const description = typeof body.description === "string" ? body.description.trim() : current.description;
    const eventDate = typeof body.eventDate === "string" ? body.eventDate.trim() : current.eventDate;
    const hallId = Number(body.hallId ?? current.hallId);
    const price = Number(body.price ?? current.price);

    if (!title || title.length > 120) return NextResponse.json({ error: "Укажите название до 120 символов" }, { status: 400 });
    if (!eventDate || Number.isNaN(Date.parse(eventDate))) return NextResponse.json({ error: "Укажите корректную дату" }, { status: 400 });
    if (!Number.isInteger(hallId) || hallId < 1) return NextResponse.json({ error: "Выберите зал" }, { status: 400 });
    if (!Number.isInteger(price) || price < 1 || price > 1_000_000) {
      return NextResponse.json({ error: "Цена должна быть от 1 до 1 000 000 ₽" }, { status: 400 });
    }

    const [hall] = await db.select({ id: halls.id }).from(halls).where(eq(halls.id, hallId)).limit(1);
    if (!hall) return NextResponse.json({ error: "Выбранный зал не найден" }, { status: 404 });

    if (hallId !== current.hallId) {
      const [soldTicket] = await db.select({ id: tickets.id }).from(tickets).where(eq(tickets.eventId, id)).limit(1);
      if (soldTicket) {
        return NextResponse.json({ error: "Нельзя менять зал после продажи билетов" }, { status: 409 });
      }
    }

    const [updatedEvent] = await db
      .update(events)
      .set({ title, genre, description, eventDate, hallId, price })
      .where(eq(events.id, id))
      .returning();

    return NextResponse.json(updatedEvent);
  } catch (error) {
    console.error("Failed to update event:", error);
    return NextResponse.json({ error: "Не удалось сохранить мероприятие" }, { status: 500 });
  }
}
